#include<iostream>
#include<fstream>
#include<string.h>
#include<math.h>
using namespace std;

class Masina
{
private:
	char* model_masina;
	char* motor;
	int vit_max;
	int capacitate;
	int cons_mediu[2];
	int vit_medie[2];
	const int id;

public:

	char* get_model_masina()
	{
		return this->model_masina;
	}
	void  set_model_masina(char* model)
	{
		delete[] this->model_masina;
		this->model_masina = new char[strlen(model) + 1];
		strcpy(this->model_masina, model);
	}
	char* get_motor()
	{
		return this->motor;
	}
	void set_motor(char* tip_motor)
	{

		delete[] this->motor;
		this->motor = new char[strlen(tip_motor) + 1];
		strcpy(this->motor, tip_motor);
	}
	int get_viteza_maxima()
	{
		return this->vit_max;
	}
	void set_viteza_maxima(int vit_m)
	{
		this->vit_max = vit_m;
	}
	int get_capacitate()
	{
		return this->capacitate;
	}
	void set_capacitate(int c_c)
	{
		if (c_c>1000)
			this->capacitate = c_c;
		else
			//throw new exception("Motor prea mic");
			cout << "Motor prea mic" << endl;


	}
	int get_cons_murban()
	{
		return this->cons_mediu[0];
	}
	int get_cons_m()
	{
		return this->cons_mediu[1];
	}
	void set_cons_murban(int cm)
	{
		if (cm<21 && cm>2)
			this->cons_mediu[0] = cm;
		else cout << " Consum gresit!" << endl;
	}
	void set_consum_mediu(int cm)
	{
		if (cm>2 && cm<21)
			this->cons_mediu[1] = cm;
		else cout << " Consum gresit!" << endl;
	}
	int get_vit_murban()
	{
		return this->vit_medie[0];
	}
	int get_vit_m()
	{
		return this->vit_medie[1];
	}
	void set_vit_murban(int cm)
	{
		if (cm <= 65 && cm >= 10)
			this->vit_medie[0] = cm;
		else cout << "Viteza prea mare/prea mica!" << endl;
	}
	void set_vit_m(int cm)
	{
		if (cm <= 250 && cm >= 10)
			this->vit_medie[1] = cm;
		else cout << "Viteza prea mare/prea mica!" << endl;
	}

	Masina() :id(100)
	{
		this->model_masina = new char[strlen("NOTHING") + 1];
		strcpy(this->model_masina, "NOTHING");
		this->motor = new char[strlen("NU STIM INCA") + 1];
		strcpy(this->motor, "NU STIM INCA");
		this->vit_max = 0;
		this->capacitate = 1000;
		this->cons_mediu[0] = 0;
		this->cons_mediu[1] = 0;
		this->vit_medie[0] = 0;
		this->vit_medie[1] = 0;
	}
	~Masina()
	{
		delete[] this->model_masina;
		delete[] this->motor;
	}
	Masina(char* m, char* tm, int vm, int c_c, int cons_mediu[2], int vit_medie[2], int id_nou) :id(id_nou)
	{
		this->model_masina = new char[strlen(m) + 1];
		strcpy(this->model_masina, m);
		this->motor = new char[strlen(tm) + 1];
		strcpy(this->motor, tm);
		this->vit_max = vm;
		this->capacitate = c_c;
		this->cons_mediu[0] = cons_mediu[0];
		this->cons_mediu[1] = cons_mediu[1];
		this->vit_medie[0] = vit_medie[0];
		this->vit_medie[1] = vit_medie[1];
	}
	Masina(const Masina &a) :id(a.id)
	{
		this->model_masina = new char[strlen(a.model_masina) + 1];
		strcpy(this->model_masina, a.model_masina);
		this->motor = new char[strlen(a.motor) + 1];
		strcpy(this->motor, a.motor);
		this->vit_max = a.vit_max;
		this->capacitate = a.capacitate;
		this->cons_mediu[0] = a.cons_mediu[0];
		this->cons_mediu[1] = a.cons_mediu[1];
		this->vit_medie[0] = a.vit_medie[0];
		this->vit_medie[1] = a.vit_medie[1];
	}
	Masina &operator=(const Masina a)
	{
		delete[] this->model_masina;
		delete[] this->motor;

		this->model_masina = new char[strlen(a.model_masina) + 1];
		strcpy(this->model_masina, a.model_masina);
		this->motor = new char[strlen(a.motor) + 1];
		strcpy(this->motor, a.motor);
		this->vit_max = a.vit_max;
		this->capacitate = a.capacitate;
		this->cons_mediu[0] = a.cons_mediu[0];
		this->cons_mediu[1] = a.cons_mediu[1];
		this->vit_medie[0] = a.vit_medie[0];
		this->vit_medie[1] = a.vit_medie[1];

		return *this;
	}

	void afisare()
	{
		cout << "Nume model: " << this->model_masina << endl;
		cout << "Motor de tip: " << this->motor << endl;
		cout << "Capacitate cilindrica: " << this->capacitate << endl;
		cout << "Viteza maxima: " << this->vit_max << endl;
		cout << "Consum mediu urban: " << this->cons_mediu[0] << endl;
		cout << "Consum mediu: " << this->cons_mediu[1] << endl;
		cout << "Viteza medie urban: " << this->vit_medie[0] << endl;
		cout << "Viteza medie: " << this->vit_medie[1] << endl;
		cout << endl;
	}

	//+,-,*,/,+=,-=,*=,++ (post si pre), --(post si pre), [], () (functie), !


	Masina& operator +=(const Masina &x)
	{
		cons_mediu[1] += x.cons_mediu[1];
		return *this;
	}
	Masina& operator -=(const Masina &x)
	{
		cons_mediu[1] -= x.cons_mediu[1];
		return *this;
	}
	const Masina& operator ++()
	{
		this->vit_max++;
		return *this;
	}
	const Masina operator ++(int)
	{
		Masina aux(*this);
		this->vit_max++;
		return aux;
	}
	const Masina& operator --()
	{
		this->vit_max--;
		return *this;
	}
	const Masina operator --(int)
	{
		Masina aux(*this);
		this->vit_max--;
		return aux;
	}

	Masina operator ()(int x, int cons)
	{
		this->vit_medie[0] = (this->vit_medie[0] + x);
		this->vit_medie[0] = (this->vit_medie[1] + x);
		this->cons_mediu[0] = this->cons_mediu[0] + (cons / 100)*x;
		return *this;
	}
	Masina& operator*=(const Masina& x)
	{
		cons_mediu[1] *= x.cons_mediu[1];
		return *this;
	}
	int & operator [](int i)
	{
		return this->vit_medie[i];
	}



	friend ostream & operator <<(ostream&c2, const Masina& obj);
	friend ofstream &operator <<(ofstream &c2, Masina obj);
	friend istream & operator >>(istream&c2, Masina &obj);
	friend ifstream &operator >>(ifstream &c2, Masina &obj);

};
ostream & operator <<(ostream&c2, const Masina& obj)
{
	c2 << obj.model_masina << endl;
	c2 << "engine: " << obj.motor << endl;
	c2 << "max_speed: " << obj.vit_max << endl;
	c2 << "engine_cc: " << obj.capacitate << endl;
	c2 << "avg_consumption_urban: " << obj.cons_mediu[0] << endl;
	c2 << "avg_speed_urban: " << obj.vit_medie[0] << endl;
	c2 << "avg_consumption: " << obj.cons_mediu[1] << endl;
	c2 << "avg_speed: " << obj.vit_medie[1] << endl;
	return c2;
}
ofstream &operator <<(ofstream &c2, Masina obj)
{
	c2 << obj.model_masina << endl;
	c2 << "engine: " << obj.motor << endl;
	c2 << "max_speed: " << obj.vit_max << endl;
	c2 << "engine_cc: " << obj.capacitate << endl;
	c2 << "avg_consumption_urban: " << obj.cons_mediu[0] << endl;
	c2 << "avg_speed_urban: " << obj.vit_medie[0] << endl;
	c2 << "avg_consumption: " << obj.cons_mediu[1] << endl;
	c2 << "avg_speed: " << obj.vit_medie[1] << endl;
	return c2;
}
istream & operator >>(istream&c2, Masina &obj)
{
	delete[] obj.motor;
	delete[] obj.model_masina;
	char aux[100], aux1[100];
	cout << "Model masina: ";
	c2 >> aux;
	obj.motor = new char[strlen(aux) + 1];
	strcpy(obj.motor, aux);
	cout << endl << "Motor: ";
	c2 >> aux1;
	obj.motor = new char[strlen(aux1) + 1];
	strcpy(obj.motor, aux1);
	cout << endl << "Capacitate: ";
	c2 >> obj.capacitate;
	cout << endl << "Viteza maxima: ";
	c2 >> obj.vit_max;
	cout << endl << "Consum mediu urban: ";
	c2 >> obj.cons_mediu[0];
	cout << endl << "Consum mediu: ";
	c2 >> obj.cons_mediu[1];
	cout << endl << "Viteza medie urban: ";
	c2 >> obj.vit_medie[0];
	cout << endl << "Viteza medie: ";
	c2 >> obj.vit_medie[1];
	cout << endl;
	return c2;
}
ifstream &operator >>(ifstream &c2, Masina &obj)
{
	delete[] obj.motor;
	delete[] obj.model_masina;
	char aux[100], aux1[100];
	c2 >> aux;
	obj.model_masina = new char[strlen(aux) + 1];
	strcpy(obj.model_masina, aux);
	c2 >> aux;
	c2 >> aux1;
	obj.motor = new char[strlen(aux1) + 1];
	strcpy(obj.motor, aux1);
	c2 >> aux;
	c2 >> obj.vit_max;
	c2 >> aux;
	c2 >> obj.capacitate;
	c2 >> aux;
	c2 >> obj.cons_mediu[0];
	c2 >> aux;
	c2 >> obj.cons_mediu[1];
	c2 >> aux;
	c2 >> obj.vit_medie[0];
	c2 >> aux;
	c2 >> obj.vit_medie[1];
	cout << endl;
	return c2;
}




class Localitate
{
private:
	char* nume;
	long double lat;
	long double lon;
	static int nr_localitati;

public:

	long double get_lat()
	{
		return this->lat;
	}
	void set_lat(long double lat)
	{
		if (lat>40 && lat <= 90)
			this->lat = lat;
		else
			cout << "Informatie eronata!" << endl;
	}
	long double get_lon()
	{
		return this->lon;
	}
	void set_lon(long double lon)
	{
		if (lon>40 && lon <= 90)
			this->lon = lon;
		else
			cout << "Informatie eronata!" << endl;
	}
	int get_nr_localitati()
	{
		return this->nr_localitati;
	}
	void set_nume(char* n_l)
	{
		delete[] this->nume;
		this->nume = new char[strlen(n_l) + 1];
		strcpy(this->nume, n_l);
	}

	Localitate()
	{
		this->nume = NULL;
		this->lat = 60;
		this->lon = 60;
		this->nr_localitati = this->nr_localitati + 0;
	}
	~Localitate()
	{
		delete[] this->nume;
	}
	Localitate(char* nume, long double lat, long double lon)
	{
		this->nume = new char[strlen(nume) + 1];
		strcpy(this->nume, nume);
		this->lat = lat;
		this->lon = lon;
		this->nr_localitati++;
	}
	Localitate(const Localitate &a)
	{
		this->nume = new char[strlen(a.nume) + 1];
		strcpy(this->nume, a.nume);
		this->lat = a.lat;
		this->lon = a.lon;
		this->nr_localitati++;

	}
	Localitate &operator=(const Localitate a)
	{
		delete[] this->nume;
		this->nume = new char[strlen(a.nume) + 1];
		strcpy(this->nume, a.nume);
		this->lat = a.lat;
		this->lon = a.lon;
		this->nr_localitati++;

		return *this;
	}

	friend ostream & operator <<(ostream&c2, const Localitate& obj);
	friend istream & operator >>(istream&c2, Localitate &obj);
	friend ofstream &operator <<(ofstream&c2, Localitate obj);
	friend ifstream & operator <<(ifstream &c2, Localitate &obj);

};
ostream & operator <<(ostream&c2, const Localitate& obj)
{
	c2 << endl << obj.nume << endl;
	c2 << obj.lat << endl;
	c2 << obj.lon << endl;

	return c2;
}
ofstream &operator <<(ofstream&c2, Localitate obj)
{
	c2 << endl << obj.nume << endl;
	c2 << obj.lat << endl;
	c2 << obj.lon << endl;


	return c2;
}
istream & operator >>(istream&c2, Localitate &obj)
{
	delete[] obj.nume;
	char aux[100];
	long double aux1, aux2;
	c2 >> aux;
	c2 >> aux1;
	c2 >> aux2;
	if ((strcmp(obj.nume, aux) == 0) && (aux1 == obj.lat) && (aux2 == obj.lon))
	{
		cout << "Este la fel" << endl;
	}
	else
	{
		obj.nume = new char[strlen(aux) + 1];
		strcpy(obj.nume, aux);
		c2 >> obj.lat;
		c2 >> obj.lon;
		obj.nr_localitati++;
	}
	return c2;
}
ifstream & operator <<(ifstream &c2, Localitate &obj)
{
	delete[] obj.nume;
	char aux[100];
	long double aux1, aux2;
	c2 >> aux;
	c2 >> aux1;
	c2 >> aux2;
	if ((strcmp(obj.nume, aux) == 0) && (aux1 == obj.lat) && (aux2 == obj.lon))
	{
		cout << "Este la fel" << endl;
	}
	else
	{
		obj.nume = new char[strlen(aux) + 1];
		strcpy(obj.nume, aux);
		c2 >> obj.lat;
		c2 >> obj.lon;
		obj.nr_localitati++;
	}
	return c2;
}




class Telematics
{
private:
	long double lat;
	long double lon;
	static int nr_tele;
	int vit;
	char* nume_masina;
	unsigned long long  time;

public:

	unsigned long long get_time()
	{
		return time;
	}
	long double get_lat()
	{
		return this->lat;
	}
	void set_lat(long double lat)
	{
		if (lat>45 && lat <= 90)
			this->lat = lat;
		else
			cout << "Informatie invalida" << endl;
	}
	long double get_lon()
	{
		return this->lon;
	}
	void set_lon(long double lon)
	{
		if (lon>45 && lon <= 90)
			this->lon = lon;
		else
			cout << "Informatie invalida" << endl;
	}
	int get_vit()
	{
		return this->vit;
	}
	void set_vit(int vit)
	{
		if (vit<250 && vit >= 5)
			this->vit = vit;
		else
			cout << "Viteza eronata!" << endl;
	}
	char* get_nume()
	{
		return this->nume_masina;
	}
	void set_nume(char* nume)
	{
		delete[] this->nume_masina;
		this->nume_masina = new char[strlen(nume) + 1];
		strcpy(this->nume_masina, nume);
	}
	int get_nr_tele()
	{
		return this->nr_tele;
	}

	Telematics()
	{
		this->nume_masina = NULL;
		this->vit = 0;
		this->lat = 90;
		this->lon = 89;
		time = 0;
		nr_tele = nr_tele + 0;
	}

	~Telematics()
	{
		delete[] this->nume_masina;
	}
	// Constructor cu parametri
	Telematics(char* nume_masina, long double latitudine, long double longitudine, int viteza)
	{
		this->nume_masina = new char[strlen(nume_masina) + 1];
		strcpy(this->nume_masina, nume_masina);
		this->vit = viteza;
		this->lat = latitudine;
		this->lon = longitudine;
		nr_tele++;
	}
	//Constructor de copiere
	Telematics(const Telematics &a)
	{
		this->nume_masina = new char[strlen(a.nume_masina) + 1];
		strcpy(this->nume_masina, a.nume_masina);
		this->vit = a.vit;
		this->lat = a.lat;
		this->lon = a.lon;
		nr_tele++;
	}
	// Operator =
	Telematics &operator=(const Telematics a)
	{
		delete[] this->nume_masina;
		this->nume_masina = new char[strlen(a.nume_masina) + 1];
		strcpy(this->nume_masina, a.nume_masina);
		this->vit = a.vit;
		this->lat = a.lat;
		this->lon = a.lon;
		return *this;
	}

	long double distanta(const Telematics &x)
	{
		long double d;
		d = sqrt((lat - x.lat)*(lat - x.lat) + (lon - x.lon)*(lon - x.lon));
		return d;
	}

	friend ostream & operator <<(ostream&c2, const Telematics& obj);
	friend istream & operator >>(istream&c2, Telematics &obj);
	friend ofstream & operator <<(ofstream&c2, Telematics obj);
	friend ifstream & operator >>(ifstream&c2, Telematics &obj);
};
ostream & operator <<(ostream&c2, const Telematics& obj)
{
	c2 << obj.nume_masina << endl;
	c2 << obj.time << endl;
	c2 << obj.lat << endl;
	c2 << obj.lon << endl;
	c2 << obj.vit << endl;
	return c2;
}
ofstream & operator <<(ofstream&c2, Telematics obj)
{
	c2 << obj.nume_masina << endl;
	c2 << obj.time << endl;
	c2 << obj.lat << endl;
	c2 << obj.lon << endl;
	c2 << obj.vit << endl;

	return c2;
}
istream & operator >>(istream& c2, Telematics &obj)
{
	delete[] obj.nume_masina;
	char aux[100];
	c2 >> aux;
	obj.nume_masina = new char[strlen(aux) + 1];
	strcpy(obj.nume_masina, aux);
	c2 >> obj.time;
	c2 >> obj.lat;
	c2 >> obj.lon;
	c2 >> obj.vit;
	obj.nr_tele++;

	return c2;
}
ifstream & operator >>(ifstream&c2, Telematics &obj)
{
	delete[] obj.nume_masina;
	char aux[100];
	c2 >> aux;
	obj.nume_masina = new char[strlen(aux) + 1];
	strcpy(obj.nume_masina, aux);
	c2 >> obj.time;
	c2 >> obj.lat;
	c2 >> obj.lon;
	c2 >> obj.vit;
	obj.nr_tele++;
	return c2;
}



class Baza
{
protected:
	char* restictii;

public:
	char* get_restictii()
	{
		return this->restictii;
	}
	void set_nume(char* n)
	{
		if (restictii != NULL)
			delete[] restictii;

		this->restictii = new char[strlen(n) + 1];
		strcpy(this->restictii, n);
	}
	Baza()
	{
		restictii = NULL;
	}
	Baza(char*x)
	{
		restictii = new char[strlen(x) + 1];
		strcpy(restictii, x);
	}
	Baza(const Baza&x)
	{
		restictii = new char[strlen(x.restictii) + 1];
		strcpy(restictii, x.restictii);
	}
	~Baza()
	{
		delete[]restictii;
	}
	Baza& operator=(const Baza& x)
	{
		if (restictii != NULL)
			delete[] restictii;

		restictii = new char[strlen(x.restictii) + 1];
		strcpy(restictii, x.restictii);
		return *this;
	}

};




class Cerc :public Baza
{
private:
	long double punct[2];
	float raza;

public:

	long double get_p_x()
	{
		return this->punct[0];
	}
	long double get_p_y()
	{
		return this->punct[1];
	}

	void set_punct(long double p[2])
	{
		this->punct[0] = p[0];
		this->punct[1] = p[1];
	}

	float get_raza()
	{
		return this->raza;
	}
	void set_raza(float r)
	{
		this->raza;
	}

	Cerc()
	{
		this->raza = 1;
		this->punct[0] = 0;
		this->punct[1] = 0;
	}
	Cerc(long double punct[2], float raza, char*n) :Baza(n)
	{
		this->raza = raza;
		this->punct[0] = punct[0];
		this->punct[1] = punct[1];
	}
	Cerc(Cerc const &c) :Baza(c)
	{
		this->raza = c.raza;
		this->punct[0] = c.punct[0];
		this->punct[1] = c.punct[1];
	}
	Cerc &operator=(Cerc const c)
	{
		(Baza&)(*this) = c;
		this->raza = c.raza;
		this->punct[0] = c.punct[0];
		this->punct[1] = c.punct[1];
		return *this;
	}
	const Cerc operator -(const Cerc& x)
	{
		Cerc aux(x);
		aux.raza = raza - aux.raza;
		aux.punct[0] = this->punct[0] - aux.punct[0];
		aux.punct[1] = this->punct[1] - aux.punct[1];
		return aux;
	}
	const Cerc operator +(const Cerc& x)
	{
		Cerc aux(x);
		aux.raza = raza + aux.raza;
		aux.punct[0] = aux.punct[0] + this->punct[0];
		aux.punct[1] = aux.punct[1] + this->punct[1];
		return aux;
	}
	const Cerc operator *(const Cerc& x)
	{
		Cerc aux(x);
		aux.raza = raza*aux.raza;
		aux.punct[0] = aux.punct[0] * this->punct[0];
		aux.punct[1] = aux.punct[1] * this->punct[1];
		return aux;
	}
	const Cerc operator /(const Cerc& x)
	{
		Cerc aux(x);
		aux.raza = raza / aux.raza;
		aux.punct[0] = this->punct[0] / aux.punct[0];
		aux.punct[1] = this->punct[1] / aux.punct[1];
		return aux;
	}
	Cerc&  operator *=(const Cerc& x)
	{
		this->raza *= x.raza;
		return *this;
	}
	Cerc&  operator /=(const Cerc& x)
	{
		this->raza /= x.raza;
		return *this;
	}

	long double &operator [] (int i)
	{
		if (i<2)
			return this->punct[i];
		else
		{
			//arunca exceptiile;
			throw "Gresit";
			return this->punct[0];
		}
	}
	// verifica daca un punct se afla in cerc
	int check_cerc(long double x, long double y)
	{
		long double dist;
		dist = sqrt(((punct[0] - x)*(punct[0] - x)) + ((punct[1] - y)*(punct[1] - y)));
		//cout<< "Dist = " << dist << endl;
		if (dist<raza)
			return 1;
		else
			return 0;
	}

	friend ostream & operator <<(ostream&c2, const Cerc& obj);
	friend istream & operator >>(istream&c2, Cerc &obj);
	friend ofstream & operator <<(ofstream&c2, Cerc obj);
	friend ifstream & operator >>(ifstream&c2, Cerc &obj);
};
ostream & operator <<(ostream&c2, const Cerc& obj)
{
	c2 << "type: circle" << endl;
	c2 << "restrictions: " << obj.restictii << endl;
	c2 << "point: " << obj.punct[0] << ";" << obj.punct[1] << endl;
	c2 << "radius: " << obj.raza << endl;
	return c2;
}
ofstream & operator <<(ofstream&c2, Cerc obj)
{
	c2 << "type: circle" << endl;
	c2 << "restrictions: " << obj.restictii << endl;
	c2 << "point: " << obj.punct[0] << ";" << obj.punct[1] << endl;
	c2 << "radius: " << obj.raza << endl;
	return c2;
}
istream & operator >>(istream&c2, Cerc &obj)
{
	c2 >> obj.raza;
	c2 >> obj.punct[0];
	c2 >> obj.punct[1];
	return c2;
}
ifstream & operator >>(ifstream&c2, Cerc &obj)
{
	char aux[100];
	c2 >> aux;
	c2 >> aux;
	obj.restictii = new char[strlen(aux) + 1];
	strcpy(obj.restictii, aux);
	c2 >> aux;
	c2 >> obj.punct[0];
	c2 >> aux;
	c2 >> obj.punct[1];
	c2 >> aux;
	c2 >> obj.raza;

	return c2;

}




class Dreptunghi :public Baza
{
private:
	long double p1[2];
	long double p2[2];

public:
	long double get_p1_x()
	{
		return this->p1[0];
	}
	long double get_p1_y()
	{
		return this->p1[1];
	}

	void set_punct1(long double p[2])
	{
		this->p1[0] = p[0];
		this->p1[1] = p[1];
	}
	long double get_p2_x()
	{
		return this->p2[0];
	}
	long double get_p2_y()
	{
		return this->p2[1];
	}

	void set_punct2(long double p[2])
	{
		this->p2[0] = p[0];
		this->p2[1] = p[1];
	}

	Dreptunghi()
	{
		this->p1[0] = 0;
		this->p1[1] = 0;
		this->p2[0] = 1;
		this->p2[1] = 1;
	}
	Dreptunghi(long double p1[2], long double p2[2], char*n) :Baza(n)
	{
		this->p1[0] = p1[0];
		this->p1[1] = p1[1];
		this->p2[0] = p2[0];
		this->p2[1] = p2[1];
	}
	Dreptunghi(Dreptunghi const &d) :Baza(d)
	{
		this->p1[0] = d.p1[0];
		this->p1[1] = d.p1[1];
		this->p2[0] = d.p2[0];
		this->p2[1] = d.p2[1];
	}
	Dreptunghi &operator=(const Dreptunghi& d)
	{
		(Baza&)(*this) = d;
		this->p1[0] = d.p1[0];
		this->p1[1] = d.p1[1];
		this->p2[0] = d.p2[0];
		this->p2[1] = d.p2[1];
		return *this;
	}
	//verifica daca un punct de afla in dreptunghi
	int check_drep(long double x, long double y)
	{
		if (p1[0]<x && x<p2[0] && p1[1]<y && y<p2[1])
			return 1;
		else
			return 0;
	}

	friend ostream & operator <<(ostream&c2, const Dreptunghi& obj);
	friend istream & operator >>(istream&c2, Dreptunghi &obj);
	friend ofstream & operator <<(ofstream&c2, Dreptunghi obj);
	friend ifstream & operator >>(ifstream&c2, Dreptunghi &obj);

};
ostream & operator <<(ostream&c2, const Dreptunghi& obj)
{
	c2 << "type: rectangle" << endl;
	c2 << "restrictions: " << obj.restictii << endl;
	c2 << "left_up_corner: " << obj.p1[0] << ";" << obj.p1[1] << endl;
	c2 << "right_down_corner: " << obj.p2[0] << ";" << obj.p2[1] << endl;

	return c2;
}
ofstream & operator <<(ofstream&c2, Dreptunghi obj)
{
	c2 << "type: rectangle" << endl;
	c2 << "restrictions: " << obj.restictii << endl;
	c2 << "left_up_corner: " << obj.p1[0] << ";" << obj.p1[1] << endl;
	c2 << "right_down_corner: " << obj.p2[0] << ";" << obj.p2[1] << endl;

	return c2;
}
istream & operator >>(istream&c2, Dreptunghi &obj)
{
	c2 >> obj.restictii;
	c2 >> obj.p1[0];
	c2 >> obj.p1[1];
	c2 >> obj.p2[0];
	c2 >> obj.p2[1];
	return c2;
}
ifstream & operator >>(ifstream&c2, Dreptunghi &obj)
{
	char aux[100];
	c2 >> aux;
	c2 >> aux;
	obj.restictii = new char[strlen(aux) + 1];
	strcpy(obj.restictii, aux);
	c2 >> aux;
	c2 >> obj.p1[0];
	c2 >> aux;
	c2 >> obj.p1[1];
	c2 >> aux;
	c2 >> obj.p2[0];
	c2 >> aux;
	c2 >> obj.p2[1];
	return c2;
}

int Telematics::nr_tele = 0;
int Localitate::nr_localitati = 0;
