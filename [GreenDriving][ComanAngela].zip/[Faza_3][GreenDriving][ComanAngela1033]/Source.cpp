#include "Clase.h"
#include<iostream>
#include<string>

int main(int argc, char** argv)
{
	cout << "Va rugam asteptati, incarcarea datelor se va face intr-un scurt timp!" << endl;
	if (argc == 1)
	{
		argv[1] = "auto.txt";
		argv[2] = "geofence.txt";
		argv[3] = "telematics.txt";
	}
	string path = argv[3];
	//CITIRE auto-------------------
	ifstream fmasina(argv[1]);
	Masina *vect_auto;
	vect_auto = new Masina[3];
	for (int i = 0; i<3; i++)
		fmasina >> vect_auto[i];
	fmasina.close();

	//CITIRE telematics-------------------
LOOPlapath:
	ifstream ftele(path.c_str());
	Telematics *vect_tele;
	int lines = 0;
	std::string unused;
	while (std::getline(ftele, unused))
		lines++;

	vect_tele = new Telematics[(lines - 1) / 4];
	ftele.close();
	ftele.open(path.c_str());
	for (int i = 0; i<(lines - 1) / 4; i++)
	{
		ftele >> vect_tele[i];

	}
	ftele.close();


	//CITIRE geofence-------------------
	ifstream fgeo(argv[2]);
	Cerc *vect_cerc;
	Dreptunghi *vect_drep;
	vect_cerc = new Cerc[3];
	vect_drep = new Dreptunghi[3];
	char buf[256];
	int i = 0, j = 0;
	while (!fgeo.eof())
	{
		fgeo.getline(buf, 256, '\n');
		if (string(buf).find("circle") != string::npos)
		{
			fgeo >> vect_cerc[i];
			i++;
		}
		if (string(buf).find("rectangle") != string::npos)
		{
			fgeo >> vect_drep[j];
			j++;
		}
	}
	
	//--------------------------------------------------------------------
	//MENIU
	string input = "  ";

LOOP: do{
	cout << endl;
	cout << "\t\t Meniu:  \n";
	cout << "\t\t=======" << endl;
	cout << "\t\t1: Generati rapoarte\n"
		"\t\t2: Dati path catre alt fisier telematic\n"
		"\t\t3: Salvati datele in fisiere binare\n"
		"\t\t4: Schimbati regulile geofence\n"
		"\t\t5: Copiati continutul unui fisier\n"
		"\t\t6: Stergeti un fisier\n"
		"\t\t7: Exit\n\n";

	cout << "Alege una din optiuni (1, 2,3,4 sau 5): ";
	cin >> input;
	
	if (input == "1")
	{
		system("cls");
		cout <<endl<< "Alegeti tipul autovehiculului: ";
		char aut[6];
		cin >> aut;
		long double d = 0;
		int tim=0;
		int vit = 0, puncte = 0;
		for (i = 0; i < (lines - 1) / 4; i++)
		if (strcmp(vect_tele[i].get_nume(), aut) == 0)
		{
			d = d + vect_tele[i].distanta(vect_tele[i + 1]);
			vit = vit + vect_tele[i].get_vit();
			puncte++;
			tim = tim + (vect_tele[i+1].get_time() - vect_tele[i].get_time());
		}

	LOOP2:
		cout << endl<<endl;
		cout << "\t\t Meniu Rapoarte pentru "<<aut<<": \n";
		cout << "\t\t==============================" << endl;
		cout << "\t\t1: Afisati numar puncte telematice\n"
			"\t\t2: Drum parcurs\n"
			"\t\t3: Viteza medie\n"
			"\t\t4: Timp\n"
			"\t\t5: Salvati raport intr-un fisier\n"
			"\t\t6: Back\n\n";

		cout << "Alege una din optiuni (1, 2,3,4 sau 5): ";
		cin >> input;

		if (input == "1")
		{
			system("cls");

			cout << endl << "Numar puncte telematice totale:  " << vect_tele[0].get_nr_tele() << endl;
			cout << endl << "Numar puncte telematice pentru " <<aut<<": "<< puncte << endl;
			goto LOOP2;
		}
		else if (input == "2")
		{
			system("cls");
			cout << endl << "Autovehiculul " << aut << " a parcurs distanta: " << d<<endl;
			goto LOOP2;
		}
		else if (input == "3")
		{
			system("cls");
			cout<<"Viteza medie :" << vit / puncte << endl;
			goto LOOP2;
		}
		else if (input == "4")
		{
			system("cls");
			cout << "Timpul in care a parcurs distanta : " <<tim/1000<< " secunde"<<endl;
			goto LOOP2;
		}

		else if (input == "5")
		{
			system("cls");
			cout << "dati numele fisierului in care doriti sa salvati raportul" << endl;
			string nume;
			cin >> nume;
			ofstream save(nume.c_str());
			save << aut << ":" << endl << "Distanta: " << d << endl << "Viteza: " << vit / puncte << endl << "Timp: "<<tim/1000;

			goto LOOP2;
		}
		else if (input == "6")
		{
			system("cls");
			goto LOOP;
		}
	}

	else if (input == "2")
	{
		system("cls");
		cout << "Path: ";
		cin >> path;
		goto LOOPlapath;
	}
	else if (input == "3")
	{
		system("cls");
		cout << "dati numele fisierului in care doriti sa salvati datele telematice (.dat)" << endl;
		string nume_fis;
		cin >> nume_fis;
		ofstream sav(nume_fis.c_str(), ios::app | ios::out | ios::binary);
		ftele.open(path.c_str());
		for (int i = 0; i<(lines - 1) / 4; i++)
		{
			sav.write((char*)&vect_tele[i], sizeof(Telematics));
		}
		ftele.close();

		goto LOOP;
	}
	else if (input == "4")
	{
		system("notepad.exe geofence.txt");
		goto LOOP;
	}
	else if (input == "5")
	{
		system("cls");
		string nume_fis;
		cout << "Ce fisier doriti sa copiati?(auto.txt/geofence.txt/telematics.txt) ";
		cin >> nume_fis;
		ifstream    inFile(nume_fis.c_str());
		cout << "Dati numele fisierului nou: ";
		cin >> nume_fis;
		ofstream    outFile(nume_fis.c_str());

		outFile << inFile.rdbuf();
		goto LOOP;
	}
	else if (input == "6")
	{
		system("cls");
		string nume_fis;
		cout << "Ce fisier doriti sa stergeti? ";
		cin >> nume_fis;
		remove(nume_fis.c_str());
		goto LOOP;
	}
	else if (input == "7")
	{
		return 0;
	}
	else {
		cout << "Ati introdus o valoare gresita!\n" << endl;
	}
} while (1);


	  return 0;
}
